from lessons.L7.custom_module_example.my_module import my_function
from lessons.L7.custom_module_example.my_module_2.processors import Processor

my_function()
p = Processor()
p.process()
