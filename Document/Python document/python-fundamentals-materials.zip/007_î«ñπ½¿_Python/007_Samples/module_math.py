import math

print(math.sqrt(16))
print(math.pi)
print(math.e)
print(round(2.1))
print(math.ceil(2.1))
print(math.floor(2.99999))
print(math.isnan(math.nan))
print(math.exp(2))
print(math.log(8, 2))
