from django.apps import AppConfig


class CeleryRedisConfig(AppConfig):
    name = 'celery_redis'
