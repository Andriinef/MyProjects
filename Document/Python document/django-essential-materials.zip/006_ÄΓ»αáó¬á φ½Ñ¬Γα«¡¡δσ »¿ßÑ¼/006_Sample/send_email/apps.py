from django.apps import AppConfig


class SendEmailConfig(AppConfig):
    name = 'send_email'
