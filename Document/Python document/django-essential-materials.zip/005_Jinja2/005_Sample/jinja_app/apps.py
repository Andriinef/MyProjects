from django.apps import AppConfig


class JinjaAppConfig(AppConfig):
    name = 'jinja_app'
